/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "BLE.h"

int DeviceControl( uint8 links , uint8 midden , uint8 rechts)
{
    uint8 periodMotorL = 255;
    uint8 periodMotorR = 255; 
    
    if(midden >= 45 && links >= 45 && rechts >= 45)
    {
        Motor_Links_WritePeriod(periodMotorL);
        Motor_Rechts_WritePeriod(periodMotorR);
    } 
    
        else if(midden <= 50 && links >= 50 && rechts >= 50)
        {
              Motor_Links_WritePeriod(periodMotorL -= 15);
              Motor_Rechts_WritePeriod(periodMotorR -= 15);
              CyDelay(500);
        }
        
         else if(midden <= 15 && links >= 50 && rechts >= 50)
            {
                  Motor_Links_WritePeriod(0);
                  Motor_Rechts_WritePeriod(0);
                  CyDelay(500);
            }
    
    
    
    return 0;

}




/* [] END OF FILE */
